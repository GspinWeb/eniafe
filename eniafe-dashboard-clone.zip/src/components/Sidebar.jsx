
export default function Sidebar() {
  const items = ["Dashboard","Markets","Forex","Indices","Crypto","Signals","Analytics","Settings"]

  return (
    <div className="w-64 bg-panel border-r border-border p-4">
      <div className="text-green font-bold text-xl mb-6">ENIAFE</div>
      <div className="space-y-3 text-sm text-gray-300">
        {items.map(i => (
          <div key={i} className="hover:text-white cursor-pointer">{i}</div>
        ))}
      </div>
    </div>
  )
}
