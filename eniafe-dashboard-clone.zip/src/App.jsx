
import Sidebar from "./components/Sidebar"
import TopBar from "./components/TopBar"
import Ticker from "./components/Ticker"
import Dashboard from "./pages/Dashboard"

export default function App() {
  return (
    <div className="flex h-screen bg-bg">
      <Sidebar />
      <div className="flex flex-col flex-1 overflow-hidden">
        <TopBar />
        <Ticker />
        <Dashboard />
      </div>
    </div>
  )
}
