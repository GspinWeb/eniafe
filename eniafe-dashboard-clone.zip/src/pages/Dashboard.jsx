
import Stats from "../sections/Stats"
import Table from "../sections/Table"
import RightPanel from "../sections/RightPanel"

export default function Dashboard(){
  return (
    <div className="flex flex-1 overflow-hidden">

      <div className="flex-1 p-4 space-y-4 overflow-y-auto">
        <Stats />
        <Table />
      </div>

      <div className="w-96 border-l border-border p-4 space-y-4 overflow-y-auto">
        <RightPanel />
      </div>

    </div>
  )
}
